package com.example.avatar.activities;

import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import com.example.avatar.R;
import com.example.avatar.utils.SharedPrefsUtil;
import com.theartofdev.edmodo.cropper.CropImageView;

import butterknife.BindView;
import butterknife.ButterKnife;

public class CropImageActivity extends AppCompatActivity implements View.OnClickListener {
    @BindView(R.id.img_crop)
    CropImageView mCropImage;
    @BindView(R.id.btn_save)
    Button mSave;
    private String cropPath;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crop_image);
        ButterKnife.bind(this);
        initImage();
        mSave.setOnClickListener(this);
    }
    
    private void initImage(){
        if (SharedPrefsUtil.getStringPreference(this, "gallery_path") != null) {
            String path = SharedPrefsUtil.getStringPreference(this, "gallery_path");
            mCropImage.setImageUriAsync(Uri.parse(path));
            cropPath = new String(path);
        } else if (SharedPrefsUtil.getStringPreference(this, "photo_path") != null) {
            String path = SharedPrefsUtil.getStringPreference(this, "photo_path");
            mCropImage.setImageUriAsync(Uri.parse(path));
            cropPath = new String(path);
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btn_save:
                SharedPrefsUtil.setStringPreference(this, "crop_path", cropPath);
                SharedPrefsUtil.setStringPreference(this, "gallery_path", null);
                SharedPrefsUtil.setStringPreference(this, "photo_path", null);
                setResult(RESULT_OK);
                finish();
                break;
        }
    }
}
