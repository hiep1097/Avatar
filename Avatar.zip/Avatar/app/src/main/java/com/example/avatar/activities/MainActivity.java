package com.example.avatar.activities;

import android.Manifest;
import android.app.Dialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.FileProvider;
import android.support.v4.graphics.PathUtils;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.example.avatar.R;
import com.example.avatar.utils.PathUtil;
import com.example.avatar.utils.SharedPrefsUtil;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import butterknife.BindView;
import butterknife.ButterKnife;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    @BindView(R.id.img1) ImageView mImage;
    private Button mChupHinh, mThuVien, mCancel;
    private Dialog dialogSelectPhoto;
    private LinearLayout.LayoutParams layoutParams;
    private String currentPhotoPath;
    private static final int PICK_IMAGE = 1;
    private static final int TAKE_PHOTO = 2;
    private static final int CROP_IMAGE = 3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);
        setDialogSelectPhoto();
        mImage.setOnClickListener(this);
    }

    private void setDialogSelectPhoto(){
        dialogSelectPhoto = new Dialog(this);
        dialogSelectPhoto.setContentView(R.layout.dialog_select_photo);
        dialogSelectPhoto.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialogSelectPhoto.getWindow().setGravity(Gravity.BOTTOM);
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
        lp.copyFrom(dialogSelectPhoto.getWindow().getAttributes());
        lp.width = WindowManager.LayoutParams.MATCH_PARENT;
        lp.height = WindowManager.LayoutParams.MATCH_PARENT;
        dialogSelectPhoto.getWindow().setAttributes(lp);
        mChupHinh = dialogSelectPhoto.findViewById(R.id.btn_chuphinh);
        mThuVien = dialogSelectPhoto.findViewById(R.id.btn_thuvien);
        mCancel = dialogSelectPhoto.findViewById(R.id.btn_cancel);
        mChupHinh.setOnClickListener(this);
        mThuVien.setOnClickListener(this);
        mCancel.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.img1:
                dialogSelectPhoto.show();
                break;
            case R.id.btn_chuphinh:
                dialogSelectPhoto.dismiss();
                initPermissionWrite();
                break;
            case R.id.btn_thuvien:
                dialogSelectPhoto.dismiss();
                initPermissionRead();
                break;
            case R.id.btn_cancel:
                dialogSelectPhoto.dismiss();
                break;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {
            case 4: {
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    pickImage();
                } else {
                    Toast.makeText(this, "Hãy cấp quyền đọc bộ nhớ!", Toast.LENGTH_SHORT).show();
                }
                return;
            }
            case 5: {
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    takePhoto();
                } else {
                    Toast.makeText(this, "Hãy cấp quyền ghi bộ nhớ!", Toast.LENGTH_SHORT).show();
                }
                return;
            }

            // other 'case' lines to check for other
            // permissions this app might request.
        }
    }

    public void initPermissionWrite() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 5);

            } else {
                takePhoto();
            }
        }
    }

    public void initPermissionRead() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 4);

            } else {
                pickImage();
            }
        }
    }

    private void takePhoto() {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        // Ensure that there's a camera activity to handle the intent
        if (takePictureIntent.resolveActivity(this.getPackageManager()) != null) {
            // Create the File where the photo should go
            File photoFile = null;
            try {
                photoFile = createImageFile();
            } catch (IOException ex) {
                // Error occurred while creating the File
            }
            // Continue only if the File was successfully created
            if (photoFile != null) {
                Uri photoURI = FileProvider.getUriForFile(this,
                        "com.example.android.fileprovider",
                        photoFile);
                takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
                startActivityForResult(takePictureIntent, TAKE_PHOTO);
            }
        }
    }

    private File createImageFile() throws IOException {
        // Create an image file name
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String imageFileName = "JPEG_" + timeStamp + "_";
        File storageDir = this.getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        File image = File.createTempFile(
                imageFileName,  /* prefix */
                ".jpg",         /* suffix */
                storageDir      /* directory */
        );

        // Save a file: path for use with ACTION_VIEW intents
        currentPhotoPath = image.getAbsolutePath();
        return image;
    }

    private void pickImage() {
        Intent getIntent = new Intent(Intent.ACTION_GET_CONTENT);
        getIntent.setType("image/*");
        Intent pickIntent = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        pickIntent.setType("image/*");
        Intent chooserIntent = Intent.createChooser(getIntent, "Select Image");
        chooserIntent.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{pickIntent});
        startActivityForResult(chooserIntent, PICK_IMAGE);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == PICK_IMAGE && resultCode == RESULT_OK) {
            //TODO: action
            String path = PathUtil.getInstance().getPath(this, data.getData());
            SharedPrefsUtil.setStringPreference(this, "gallery_path", path);
            SharedPrefsUtil.setStringPreference(this, "photo_path", null);
            cropImage();
        }

        if (requestCode == TAKE_PHOTO && resultCode == RESULT_OK) {
            SharedPrefsUtil.setStringPreference(this, "gallery_path", null);
            SharedPrefsUtil.setStringPreference(this, "photo_path", currentPhotoPath);
            cropImage();
        }

        if (requestCode == CROP_IMAGE && resultCode == RESULT_OK) {
            String path = SharedPrefsUtil.getStringPreference(this, "crop_path");
            mImage.setImageDrawable(Drawable.createFromPath(path));
        }
    }

    private void cropImage(){
        Intent intent = new Intent(MainActivity.this,CropImageActivity.class);
        startActivityForResult(intent,CROP_IMAGE);
    }
}
